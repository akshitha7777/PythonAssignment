arr = []
result = []

class MyError(Exception):
 
    def __init__(self, age, name, email, phn):
        self.age = age
        self.name = name
        self.email = email
        self.phn = phn

     # if length of name is greater than or equal to 3 then name is valid
    def check_name(self): 
        try:
            if len(self.name) >= 3:
                arr.append(self.name)
            else:
                raise MyError('',"Exception InvalidNameError: Name length must be greater than 3",'','')
        except MyError as error:
            print(error.name)
    
    # if age is greater than 0 then age is valid
    def check_ages(self):  
        try:
            if self.age > 0:
                arr.append(self.age)
            else:
                raise MyError("Exception AgeInvalidError: Age must be greater than 0",'','','')
        except MyError as error:
            print(error.age)
            
    # if email contains '@' and '.' then email is valid        
    def check_email(self):    
        try:
            if '.' in self.email and '@' in self.email:
                arr.append(self.email)
            else:
                raise MyError('','',"Exception InvalidEmailError: Email must contains @ and .",'')
        except MyError as error:
            print(error.email)

    # if length of phone number is 10 then phone number is valid        
    def check_phn(self):    
        try:
            if len(self.phn) == 10:
                arr.append(self.phn)
            else:
                raise MyError('','','',"Exception InvalidPhoneNumberError: Phone number should be 10 digits")
        except MyError as error:
            print(error.phn)
        
# Test data
ob = MyError(22, "akshitha", "akshi@gmail.com", "0000000000")   
ob.check_ages()
ob.check_name()
ob.check_email()
ob.check_phn()
if len(arr) == 4:
    print(arr)
else:
    arr.clear()