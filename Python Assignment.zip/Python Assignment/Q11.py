color_list_1 = set(["White", "Black", "Red"])
color_list_2 = set(["Red", "Green"])

print("\n Output :")
print(color_list_1.difference(color_list_2))