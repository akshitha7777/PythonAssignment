a = int(input("Input a number : "))
n1 = a
n2 = int(str(a)*2)
n3 = int(str(a)*3)
print("Result = ", (n1+n2+n3))