import math 
    
a = math.pi / 6 
print ("The value of sine of pi / 6 is : ", end ="") 
print (math.sin(a)) 