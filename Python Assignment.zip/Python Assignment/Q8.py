N = int(input("Enter a number : "))
if N % 2 == 0:
    print(f'Yes! {N} is an even number.')
else:
    print(f'Yes! {N} is an odd number.')