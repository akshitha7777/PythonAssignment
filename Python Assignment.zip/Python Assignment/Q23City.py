def add(a,b):
    return f"Sum of {a} and {b} is {a+b}"

def sub(a,b):
    return f"Subtraction of {a} and {b} is {a-b}"

def mul(a,b):
    return f"Multiply of {a} and {b} is {a*b}"

def div(a,b):
    return f"Division of {a} and {b} is {a/b}"
  
    