f = open("sample.txt")
print(f.read()) # read a file

f = open("sample.txt", "a")
f.write("\nMy name is Python.")  # append to file

# f = open("sample.txt", "w")
# f.write("New name") # write and replace content
f.close()