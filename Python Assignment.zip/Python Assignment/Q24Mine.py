import math
def logOf(a):
    return math.log10(a)

def expOf(b):
    return math.exp(b)

def powOf(a,b):
    return math.pow(a,b)