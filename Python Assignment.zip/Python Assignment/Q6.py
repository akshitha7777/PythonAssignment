from datetime import date

from_date = date(2014, 7, 2)
to_date = date(2014, 7, 11)
result = to_date - from_date
print(result.days,"days")