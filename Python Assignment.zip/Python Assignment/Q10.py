def concatenation(numbers):
    s = ''
    for i in numbers:
        s += str(i)
    return s

numbers = [1,2,3,4,5]
res = concatenation(numbers) 
print(res)
