def checkString(s):
    if len(s) < 2:
        return "Empty String"
    else:
        return s[:2] + s[len(s)-2:]

msg = input("Type your string : ")
res = checkString(msg)
print(res)
