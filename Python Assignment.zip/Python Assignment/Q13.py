def arguments(x,y):
    return pow((x+y),2)

n1 = int(input("Enter first number : "))
n2 = int(input("Enter second number : "))

res = arguments(n1,n2)
print("Result : ",res)