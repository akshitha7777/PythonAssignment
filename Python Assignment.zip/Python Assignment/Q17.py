  # One = DivisionByZero
def divide_by_zero(): 
    try:
        print(5/0)
    except DivisionByZero as error:
        print(error)

# Second : TypeError
def type_error(): 
    try:
        a=5
        b='0'
        print(a+b)
    except TypeError as error:
        print("Type Error, cannot perform operation of integer with string")

# Third : ValueError
def value_error(): 
    x = 0
    try:
        x=int(input('Enter a number upto 100: '))

    except ValueError:
        print("ValueError : x should be integer")

# Fourth : IndexError
def index_error():  
    try:
        arr = [1,2,3,4,5,6]
        print( arr[7] )
    except IndexError as error:
        print("IndexError : list index out of range")

 # Fifth : NameError
def name_error(): 
    try:
        s = "Hello"
        print(s2)
    except NameError as error:
        print("NameError : name s2 is not defined")
