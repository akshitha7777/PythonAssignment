numbers = [3, 6, 2, 8, 12, 93]

# Method 1
print(f"Maximum Number = {max(numbers)}")

# Method 2
max = numbers[0]
for number in numbers:
    if number > max:
        max = number
print(f"Maximum Number = {(max)}")
