import csv

with open('testdata.csv', 'w+') as f:
    writer = csv.writer(f)
    writer.writerow(["Name", "Job", "Age"])
    writer.writerow(["Akshitha", "Intern", "22"])
    writer.writerow(["Sarah", "SDE", "25"])

with open("testdata.csv", 'a') as f:
     writer = csv.writer(f)
     writer.writerow(["Joey", "PE", "27"])

with open('testdata.csv','rt')as f:
     writer = csv.reader(f)
     for row in writer:
        print(row)