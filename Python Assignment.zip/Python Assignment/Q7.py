msg = input("Enter the string : ")

if msg[:2] == 'Is':
    print("Your string is : ",msg)
else:
    print("Your string is : ", ('Is'+msg))