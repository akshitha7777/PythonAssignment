from Q24Mine import *

res1 = logOf(4)
res2 = expOf(2)
res3 = powOf(2,3)

print("", res1,"\n",res2,"\n",res3)