import math
radius = float(input("Input the radius : "))

res = round( (radius * radius * math.pi), 3)
print("Area of circle is ",res)